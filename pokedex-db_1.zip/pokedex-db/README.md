# Pokédex — Banco de Dados (SQLite + Java/Maven)

Parte do projeto responsável pela **camada de dados**. Lê o CSV dos 151 Pokémon
(Gen 1) e gera um banco SQLite (`pokedex.db`) normalizado, já com tabela de
efetividade entre tipos (TypeChart), natures e golpes.

## Como rodar

Precisa de **JDK 21+** e **Maven**. Na pasta do projeto:

```bash
# opção 1: roda direto
mvn compile exec:java

# opção 2: gera um JAR executável e roda
mvn package
java -jar target/pokedex-db-1.0.0.jar
```

Qualquer uma gera o arquivo `pokedex.db` na raiz do projeto (recriado do zero a
cada execução). Para escolher outro nome/caminho:

```bash
java -jar target/pokedex-db-1.0.0.jar caminho/meubanco.db
```

> Já incluí um `pokedex.db` pronto na raiz, gerado com exatamente o mesmo
> `schema.sql`, o mesmo CSV e os mesmos dados do código. Se quiser, é só usar.

## Estrutura

```
pokedex-db/
├── pom.xml                       # dependência: org.xerial:sqlite-jdbc
├── pokedex.db                    # banco já gerado (pronto pra usar)
└── src/main/
    ├── java/com/pokedex/db/
    │   ├── Main.java             # orquestra a criação do banco
    │   ├── Database.java         # conexão + cria o schema
    │   ├── CsvImporter.java      # lê o CSV -> pokemon, pokemon_tipo
    │   ├── TipoSeeder.java       # insere os 18 tipos
    │   ├── TypeChartSeeder.java  # popula a efetividade (forte/fraco/imune)
    │   ├── NatureSeeder.java     # insere as 25 natures
    │   └── MoveSeeder.java       # lê os CSVs de golpes e atribui 1 por Pokémon
    └── resources/
        ├── pokemons.csv          # CSV base (cabeçalho limpo, UTF-8)
        ├── golpes.csv            # catálogo de golpes (nome, tipo, poder, precisão, categoria)
        ├── pokemon_golpes.csv    # 1 golpe característico por Pokémon
        └── schema.sql            # DDL de todas as tabelas
```

## Tabelas (modelo normalizado)

- **pokemon** — dados-base do CSV (`id`, `nome`, stats, `sprite_url`).
- **tipo** — os 18 tipos. (O CSV usa 17; o 18º entra só pra completar o TypeChart.)
- **pokemon_tipo** — relação N:N. `slot` = 1 (tipo primário) ou 2 (secundário).
- **tipo_efetividade** — o TypeChart. `multiplicador` = 2.0 / 0.5 / 0.0.
  Ausência de linha = dano **neutro (1.0)**.
- **nature** — 25 natures; `stat_aumentada`/`stat_reduzida` (NULL = neutra).
- **golpe** — golpes (nome, tipo, poder, precisão, categoria).
- **pokemon_golpe** — golpes padrão de cada Pokémon.
- **time / time_pokemon / time_pokemon_golpe** — estrutura pronta pra **persistir
  o time** (nature e golpes escolhidos por slot). Se o app preferir manter o time
  só em memória, é só não usar essas tabelas.

## Como o resto do projeto usa (exemplos de consulta)

**Listar a Pokédex (tela 1):**
```sql
SELECT id, nome, sprite_url FROM pokemon ORDER BY id;
```

**Filtrar por tipo:**
```sql
SELECT p.id, p.nome FROM pokemon p
JOIN pokemon_tipo pt ON pt.pokemon_id = p.id
JOIN tipo t ON t.id = pt.tipo_id
WHERE t.nome = 'Fire';
```

**Tipos + golpes padrão de um Pokémon (card ampliado):**
```sql
SELECT t.nome FROM pokemon_tipo pt JOIN tipo t ON t.id = pt.tipo_id
WHERE pt.pokemon_id = 6 ORDER BY pt.slot;

SELECT g.nome, g.poder, g.categoria FROM pokemon_golpe pg
JOIN golpe g ON g.id = pg.golpe_id WHERE pg.pokemon_id = 6;
```

**Fraquezas/vantagens defensivas (dashboard — gráfico de teia).**
Combina os 1–2 tipos do Pokémon. A guarda `CASE` trata imunidade (0x):
```sql
SELECT atk.nome AS tipo_atacante,
       CASE WHEN MIN(COALESCE(te.multiplicador,1.0)) = 0 THEN 0
            ELSE EXP(SUM(LN(COALESCE(te.multiplicador,1.0)))) END AS dano
FROM pokemon p
JOIN pokemon_tipo pt ON pt.pokemon_id = p.id
JOIN tipo def ON def.id = pt.tipo_id
CROSS JOIN tipo atk
LEFT JOIN tipo_efetividade te
       ON te.tipo_atacante_id = atk.id AND te.tipo_defensor_id = def.id
WHERE p.id = 6
GROUP BY atk.id
HAVING dano <> 1.0
ORDER BY dano DESC;
```
(Para o Charizard isso devolve Rock 4x, Electric/Water 2x, Ground 0x, etc.)

## Notas / decisões

- **Correções aplicadas na importação:** cabeçalho ignorado; `tipo_2` vazio vira
  ausência de linha (NULL conceitual) em vez de string vazia; stats gravadas como
  `INTEGER`; CSV lido em UTF-8 (os caracteres ♀/♂ do Nidoran ficam intactos).
- **Golpes (uso visual):** cada Pokémon tem **um golpe característico/icônico**
  (ex.: Pikachu → Thunderbolt, Meowth → Pay Day, Magikarp → Splash, Mew →
  Transform), pensado só pra aparecer no card — não há sistema de combate. Os
  golpes ficam em `golpes.csv` (catálogo, 91 golpes) e a relação em
  `pokemon_golpes.csv` (1 por Pokémon); é fácil editar/ampliar sem mudar o
  schema. Obs.: o golpe nem sempre é do mesmo tipo do Pokémon — é o mais
  reconhecível dele.
- **Pendências de alinhamento:** confirmar se o time tem 3 ou 6 slots (os
  rascunhos divergem) e se o time deve persistir no banco ou ficar em memória.
- **Versão do driver:** `sqlite-jdbc 3.49.1.0` no `pom.xml` — ajuste se o time
  padronizar outra.
