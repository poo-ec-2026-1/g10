-- =====================================================================
--  POKEDEX - Esquema do banco de dados (SQLite)
--  Modelagem normalizada. Espelha as classes da UML (Pokemon, Move,
--  Trainer/Time e TypeChart/tipo_efetividade).
-- =====================================================================

PRAGMA foreign_keys = ON;

-- ----- Tipos elementais (Fire, Water, ...) --------------------------
CREATE TABLE tipo (
    id    INTEGER PRIMARY KEY AUTOINCREMENT,
    nome  TEXT NOT NULL UNIQUE
);

-- ----- Pokemon (dados-base vindos do CSV) ---------------------------
CREATE TABLE pokemon (
    id          INTEGER PRIMARY KEY,   -- corresponde ao "Nid" do CSV
    nome        TEXT    NOT NULL,
    hp          INTEGER NOT NULL,
    ataque      INTEGER NOT NULL,
    defesa      INTEGER NOT NULL,
    sp_atk      INTEGER NOT NULL,
    sp_def      INTEGER NOT NULL,
    velocidade  INTEGER NOT NULL,
    sprite_url  TEXT
);

-- ----- Tipos de cada Pokemon (1 ou 2) -------------------------------
-- Relacao N:N. slot = 1 (tipo primario) ou 2 (tipo secundario).
CREATE TABLE pokemon_tipo (
    pokemon_id  INTEGER NOT NULL REFERENCES pokemon(id),
    tipo_id     INTEGER NOT NULL REFERENCES tipo(id),
    slot        INTEGER NOT NULL,
    PRIMARY KEY (pokemon_id, tipo_id)
);

-- ----- TypeChart: efetividade entre tipos ---------------------------
-- multiplicador: 2.0 (forte), 0.5 (fraco), 0.0 (sem efeito).
-- A AUSENCIA de uma linha significa dano neutro (1.0).
CREATE TABLE tipo_efetividade (
    tipo_atacante_id  INTEGER NOT NULL REFERENCES tipo(id),
    tipo_defensor_id  INTEGER NOT NULL REFERENCES tipo(id),
    multiplicador     REAL    NOT NULL,
    PRIMARY KEY (tipo_atacante_id, tipo_defensor_id)
);

-- ----- Natures (sobe uma stat, abaixa outra; HP nunca muda) ---------
CREATE TABLE nature (
    id              INTEGER PRIMARY KEY AUTOINCREMENT,
    nome            TEXT NOT NULL UNIQUE,
    stat_aumentada  TEXT,   -- NULL = nature neutra
    stat_reduzida   TEXT
);

-- ----- Golpes / ataques (classe Move da UML) ------------------------
CREATE TABLE golpe (
    id         INTEGER PRIMARY KEY AUTOINCREMENT,
    nome       TEXT    NOT NULL,
    tipo_id    INTEGER NOT NULL REFERENCES tipo(id),
    poder      INTEGER,   -- NULL para golpes de status
    precisao   INTEGER,
    categoria  TEXT NOT NULL CHECK (categoria IN ('Physical','Special','Status'))
);

-- ----- Golpes padrao de cada Pokemon --------------------------------
CREATE TABLE pokemon_golpe (
    pokemon_id  INTEGER NOT NULL REFERENCES pokemon(id),
    golpe_id    INTEGER NOT NULL REFERENCES golpe(id),
    PRIMARY KEY (pokemon_id, golpe_id)
);

-- ----- Time do treinador (classe Trainer da UML) --------------------
-- Tabelas prontas para persistir o time. Se o app preferir manter o
-- time so em memoria, basta nao usa-las (ficam vazias).
CREATE TABLE time (
    id    INTEGER PRIMARY KEY AUTOINCREMENT,
    nome  TEXT NOT NULL
);

CREATE TABLE time_pokemon (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    time_id     INTEGER NOT NULL REFERENCES time(id),
    pokemon_id  INTEGER NOT NULL REFERENCES pokemon(id),
    nature_id   INTEGER REFERENCES nature(id),   -- NULL = sem nature (padrao)
    slot        INTEGER NOT NULL                 -- posicao no time
);

CREATE TABLE time_pokemon_golpe (
    time_pokemon_id  INTEGER NOT NULL REFERENCES time_pokemon(id),
    golpe_id         INTEGER NOT NULL REFERENCES golpe(id),
    PRIMARY KEY (time_pokemon_id, golpe_id)
);

-- ----- Indices para consultas comuns --------------------------------
CREATE INDEX idx_pokemon_tipo_tipo ON pokemon_tipo(tipo_id);
CREATE INDEX idx_pokemon_golpe_pkmn ON pokemon_golpe(pokemon_id);
CREATE INDEX idx_golpe_tipo ON golpe(tipo_id);
