package com.pokedex.repository;

import com.pokedex.db.Database;
import com.pokedex.model.Pokemon;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

/**
 * Camada de acesso a dados (padrao Repository/DAO).
 * Traduz linhas do SQLite em objetos Pokemon. A interface chama estes
 * metodos e recebe objetos Java prontos - nunca escreve SQL.
 */
public class PokemonRepository {

    private static final String COLUNAS =
            "id, nome, hp, ataque, defesa, sp_atk, sp_def, velocidade, sprite_url";

    private final Database database;

    public PokemonRepository(Database database) {
        this.database = database;
    }

    /** Todos os Pokemon, em ordem de id. Usado na grade da Pokedex. */
    public List<Pokemon> listarTodos() {
        return consultar("SELECT " + COLUNAS + " FROM pokemon ORDER BY id");
    }

    /** Busca por nome (parcial, sem diferenciar maiusculas). Barra de pesquisa. */
    public List<Pokemon> buscarPorNome(String termo) {
        return consultar("SELECT " + COLUNAS + " FROM pokemon " +
                "WHERE LOWER(nome) LIKE LOWER(?) ORDER BY id", "%" + termo + "%");
    }

    /** Filtra por tipo (ex.: "Fire"). Filtro por tipo da Pokedex. */
    public List<Pokemon> filtrarPorTipo(String tipo) {
        return consultar("SELECT p." + COLUNAS.replace(", ", ", p.") + " FROM pokemon p " +
                "JOIN pokemon_tipo pt ON pt.pokemon_id = p.id " +
                "JOIN tipo t ON t.id = pt.tipo_id WHERE t.nome = ? ORDER BY p.id", tipo);
    }

    /** Um Pokemon pelo id, ou null. Usado no card ampliado. */
    public Pokemon buscarPorId(int id) {
        List<Pokemon> r = consultar("SELECT " + COLUNAS + " FROM pokemon WHERE id = ?", id);
        return r.isEmpty() ? null : r.get(0);
    }

    /**
     * Efetividade dos tipos atacantes CONTRA este Pokemon (dashboard).
     * A multiplicacao dos tipos e feita em Java - dado vem do banco, logica fica aqui.
     * Ex.: Charizard -> {Rock=4.0, Electric=2.0, Water=2.0, Ground=0.0, ...}
     */
    public Map<String, Double> fraquezasDe(int pokemonId) {
        Map<String, Double> mult = new LinkedHashMap<>();
        String sql =
                "SELECT atk.nome AS atacante, te.multiplicador " +
                "FROM pokemon_tipo pt " +
                "JOIN tipo_efetividade te ON te.tipo_defensor_id = pt.tipo_id " +
                "JOIN tipo atk ON atk.id = te.tipo_atacante_id " +
                "WHERE pt.pokemon_id = ?";
        try (Connection conn = database.conectar();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, pokemonId);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    // se o Pokemon tem 2 tipos, multiplica os dois multiplicadores
                    mult.merge(rs.getString("atacante"), rs.getDouble("multiplicador"), (a, b) -> a * b);
                }
            }
        } catch (SQLException e) {
            throw new RuntimeException("Erro ao calcular fraquezas", e);
        }
        // ordena do mais perigoso pro menos, ignorando o neutro (1.0)
        return mult.entrySet().stream()
                .filter(e -> e.getValue() != 1.0)
                .sorted((a, b) -> Double.compare(b.getValue(), a.getValue()))
                .collect(Collectors.toMap(Map.Entry::getKey, Map.Entry::getValue,
                        (a, b) -> a, LinkedHashMap::new));
    }

    // ---------------------------------------------------------------
    //  Infra interna
    // ---------------------------------------------------------------

    private List<Pokemon> consultar(String sql, Object... params) {
        Map<Integer, Pokemon> porId = new LinkedHashMap<>();
        try (Connection conn = database.conectar();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            for (int i = 0; i < params.length; i++) {
                ps.setObject(i + 1, params[i]);
            }
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    Pokemon p = mapear(rs);
                    porId.put(p.getId(), p);
                }
            }
            enriquecer(conn, porId);   // preenche tipos e golpe
        } catch (SQLException e) {
            throw new RuntimeException("Erro na consulta", e);
        }
        return new ArrayList<>(porId.values());
    }

    private Pokemon mapear(ResultSet rs) throws SQLException {
        Pokemon p = new Pokemon();
        p.setId(rs.getInt("id"));
        p.setNome(rs.getString("nome"));
        p.setHp(rs.getInt("hp"));
        p.setAtaque(rs.getInt("ataque"));
        p.setDefesa(rs.getInt("defesa"));
        p.setSpAtk(rs.getInt("sp_atk"));
        p.setSpDef(rs.getInt("sp_def"));
        p.setVelocidade(rs.getInt("velocidade"));
        p.setSpriteUrl(rs.getString("sprite_url"));
        return p;
    }

    /** Preenche tipos (em ordem de slot) e o golpe dos Pokemon do mapa. */
    private void enriquecer(Connection conn, Map<Integer, Pokemon> porId) throws SQLException {
        if (porId.isEmpty()) return;

        try (Statement st = conn.createStatement();
             ResultSet rs = st.executeQuery(
                     "SELECT pt.pokemon_id, t.nome FROM pokemon_tipo pt " +
                     "JOIN tipo t ON t.id = pt.tipo_id ORDER BY pt.pokemon_id, pt.slot")) {
            while (rs.next()) {
                Pokemon p = porId.get(rs.getInt(1));
                if (p != null) p.getTipos().add(rs.getString(2));
            }
        }
        try (Statement st = conn.createStatement();
             ResultSet rs = st.executeQuery(
                     "SELECT pg.pokemon_id, g.nome FROM pokemon_golpe pg " +
                     "JOIN golpe g ON g.id = pg.golpe_id")) {
            while (rs.next()) {
                Pokemon p = porId.get(rs.getInt(1));
                if (p != null) p.setGolpe(rs.getString(2));
            }
        }
    }
}
