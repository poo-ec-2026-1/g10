package com.pokedex.db;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Insere os 18 tipos canonicos. Mesmo que o CSV use só 17, inserimos todos
 * para que a tabela de efetividade (TypeChart) fique completa.
 */
public class TipoSeeder {

    private static final List<String> TIPOS = List.of(
            "Normal", "Fire", "Water", "Electric", "Grass", "Ice",
            "Fighting", "Poison", "Ground", "Flying", "Psychic", "Bug",
            "Rock", "Ghost", "Dragon", "Dark", "Steel", "Fairy"
    );

    public void inserir(Connection conn) throws SQLException {
        conn.setAutoCommit(false);
        try (PreparedStatement ps = conn.prepareStatement(
                "INSERT OR IGNORE INTO tipo(nome) VALUES (?)")) {
            for (String t : TIPOS) {
                ps.setString(1, t);
                ps.addBatch();
            }
            ps.executeBatch();
        }
        conn.commit();
        conn.setAutoCommit(true);
        System.out.println("[OK] " + TIPOS.size() + " tipos inseridos.");
    }

    /** Devolve um mapa nome-do-tipo -> id, usado pelos outros seeders. */
    public static Map<String, Integer> carregarMapa(Connection conn) throws SQLException {
        Map<String, Integer> mapa = new HashMap<>();
        try (Statement st = conn.createStatement();
             ResultSet rs = st.executeQuery("SELECT id, nome FROM tipo")) {
            while (rs.next()) {
                mapa.put(rs.getString("nome"), rs.getInt("id"));
            }
        }
        return mapa;
    }
}
