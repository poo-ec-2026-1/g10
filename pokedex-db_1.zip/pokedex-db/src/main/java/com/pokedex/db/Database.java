package com.pokedex.db;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.stream.Collectors;

/**
 * Cuida da conexao com o arquivo SQLite e da criacao do esquema.
 */
public class Database {

    private final String url;

    public Database(String caminhoArquivoDb) {
        // Ex.: jdbc:sqlite:pokedex.db
        this.url = "jdbc:sqlite:" + caminhoArquivoDb;
    }

    /** Abre uma conexao com o banco (com chaves estrangeiras ligadas). */
    public Connection conectar() throws SQLException {
        Connection conn = DriverManager.getConnection(url);
        try (Statement st = conn.createStatement()) {
            st.execute("PRAGMA foreign_keys = ON;");
        }
        return conn;
    }

    /** Le o schema.sql de resources e cria todas as tabelas. */
    public void criarEsquema(Connection conn) throws SQLException {
        String sql = lerRecurso("/schema.sql");
        // Remove comentarios de linha e separa os comandos por ';'
        for (String comando : sql.split(";")) {
            String limpo = comando.lines()
                    .filter(linha -> !linha.trim().startsWith("--"))
                    .collect(Collectors.joining("\n"))
                    .trim();
            if (limpo.isEmpty()) continue;
            try (Statement st = conn.createStatement()) {
                st.execute(limpo);
            }
        }
        System.out.println("[OK] Esquema criado.");
    }

    /** Le um arquivo de src/main/resources (classpath) como texto UTF-8. */
    static String lerRecurso(String caminho) {
        try (InputStream in = Database.class.getResourceAsStream(caminho)) {
            if (in == null) throw new IllegalStateException("Recurso nao encontrado: " + caminho);
            try (BufferedReader br = new BufferedReader(new InputStreamReader(in, StandardCharsets.UTF_8))) {
                return br.lines().collect(Collectors.joining("\n"));
            }
        } catch (Exception e) {
            throw new RuntimeException("Falha ao ler recurso " + caminho, e);
        }
    }
}
