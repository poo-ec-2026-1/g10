package com.pokedex.db;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.LinkedHashMap;
import java.util.Map;

/**
 * Popula tipo_efetividade com a tabela de tipos canonica (Gen 6+).
 * So sao gravados os confrontos NAO neutros:
 *   2.0 = super eficaz (forte),  0.5 = pouco eficaz (fraco),  0.0 = sem efeito.
 * A ausencia de linha significa dano neutro (1.0).
 */
public class TypeChartSeeder {

    public void inserir(Connection conn, Map<String, Integer> tipoIds) throws SQLException {
        Map<String, Map<String, Double>> chart = construirChart();

        conn.setAutoCommit(false);
        int total = 0;
        try (PreparedStatement ps = conn.prepareStatement(
                "INSERT INTO tipo_efetividade(tipo_atacante_id, tipo_defensor_id, multiplicador) VALUES (?,?,?)")) {
            for (var atacante : chart.entrySet()) {
                Integer idAtk = tipoIds.get(atacante.getKey());
                for (var defensor : atacante.getValue().entrySet()) {
                    Integer idDef = tipoIds.get(defensor.getKey());
                    ps.setInt(1, idAtk);
                    ps.setInt(2, idDef);
                    ps.setDouble(3, defensor.getValue());
                    ps.addBatch();
                    total++;
                }
            }
            ps.executeBatch();
        }
        conn.commit();
        conn.setAutoCommit(true);
        System.out.println("[OK] " + total + " relacoes de efetividade inseridas.");
    }

    /** atacante -> { defensor -> multiplicador } (apenas valores != 1.0). */
    private Map<String, Map<String, Double>> construirChart() {
        Map<String, Map<String, Double>> c = new LinkedHashMap<>();
        c.put("Normal",   m("Rock",0.5, "Ghost",0.0, "Steel",0.5));
        c.put("Fire",     m("Fire",0.5, "Water",0.5, "Grass",2.0, "Ice",2.0, "Bug",2.0, "Rock",0.5, "Dragon",0.5, "Steel",2.0));
        c.put("Water",    m("Fire",2.0, "Water",0.5, "Grass",0.5, "Ground",2.0, "Rock",2.0, "Dragon",0.5));
        c.put("Electric", m("Water",2.0, "Electric",0.5, "Grass",0.5, "Ground",0.0, "Flying",2.0, "Dragon",0.5));
        c.put("Grass",    m("Fire",0.5, "Water",2.0, "Grass",0.5, "Poison",0.5, "Ground",2.0, "Flying",0.5, "Bug",0.5, "Rock",2.0, "Dragon",0.5, "Steel",0.5));
        c.put("Ice",      m("Fire",0.5, "Water",0.5, "Grass",2.0, "Ice",0.5, "Ground",2.0, "Flying",2.0, "Dragon",2.0, "Steel",0.5));
        c.put("Fighting", m("Normal",2.0, "Ice",2.0, "Poison",0.5, "Flying",0.5, "Psychic",0.5, "Bug",0.5, "Rock",2.0, "Ghost",0.0, "Dark",2.0, "Steel",2.0, "Fairy",0.5));
        c.put("Poison",   m("Grass",2.0, "Poison",0.5, "Ground",0.5, "Rock",0.5, "Ghost",0.5, "Steel",0.0, "Fairy",2.0));
        c.put("Ground",   m("Fire",2.0, "Electric",2.0, "Grass",0.5, "Poison",2.0, "Flying",0.0, "Bug",0.5, "Rock",2.0, "Steel",2.0));
        c.put("Flying",   m("Electric",0.5, "Grass",2.0, "Fighting",2.0, "Bug",2.0, "Rock",0.5, "Steel",0.5));
        c.put("Psychic",  m("Fighting",2.0, "Poison",2.0, "Psychic",0.5, "Dark",0.0, "Steel",0.5));
        c.put("Bug",      m("Fire",0.5, "Grass",2.0, "Fighting",0.5, "Poison",0.5, "Flying",0.5, "Psychic",2.0, "Ghost",0.5, "Dark",2.0, "Steel",0.5, "Fairy",0.5));
        c.put("Rock",     m("Fire",2.0, "Ice",2.0, "Fighting",0.5, "Ground",0.5, "Flying",2.0, "Bug",2.0, "Steel",0.5));
        c.put("Ghost",    m("Normal",0.0, "Psychic",2.0, "Ghost",2.0, "Dark",0.5));
        c.put("Dragon",   m("Dragon",2.0, "Steel",0.5, "Fairy",0.0));
        c.put("Dark",     m("Fighting",0.5, "Psychic",2.0, "Ghost",2.0, "Dark",0.5, "Fairy",0.5));
        c.put("Steel",    m("Fire",0.5, "Water",0.5, "Electric",0.5, "Ice",2.0, "Rock",2.0, "Steel",0.5, "Fairy",2.0));
        c.put("Fairy",    m("Fire",0.5, "Fighting",2.0, "Poison",0.5, "Dragon",2.0, "Dark",2.0, "Steel",0.5));
        return c;
    }

    /** Monta um mapa defensor->multiplicador a partir de pares (nome, valor). */
    private Map<String, Double> m(Object... pares) {
        Map<String, Double> mapa = new LinkedHashMap<>();
        for (int i = 0; i < pares.length; i += 2) {
            mapa.put((String) pares[i], (Double) pares[i + 1]);
        }
        return mapa;
    }
}
