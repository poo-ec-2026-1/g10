package com.pokedex.db;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Types;
import java.util.HashMap;
import java.util.Map;

/**
 * Le dois arquivos de resources e popula os golpes:
 *  - golpes.csv         -> catalogo de golpes (nome, tipo, poder, precisao, categoria)
 *  - pokemon_golpes.csv -> 1 golpe caracteristico por Pokemon (pokemon_id, golpe_nome)
 *
 * Uso puramente visual (aparece no card). Nao ha sistema de combate, entao
 * cada Pokemon tem exatamente um golpe.
 */
public class MoveSeeder {

    public void inserir(Connection conn, Map<String, Integer> tipoIds) throws SQLException {
        conn.setAutoCommit(false);

        // 1) Catalogo de golpes -> guarda nome -> id
        Map<String, Integer> golpeIds = new HashMap<>();
        try (InputStream in = MoveSeeder.class.getResourceAsStream("/golpes.csv");
             BufferedReader br = new BufferedReader(new InputStreamReader(in, StandardCharsets.UTF_8));
             PreparedStatement ps = conn.prepareStatement(
                     "INSERT INTO golpe(nome, tipo_id, poder, precisao, categoria) VALUES (?,?,?,?,?)",
                     PreparedStatement.RETURN_GENERATED_KEYS)) {

            String linha;
            boolean primeira = true;
            while ((linha = br.readLine()) != null) {
                if (primeira) { primeira = false; continue; }   // cabecalho
                if (linha.isBlank()) continue;

                String[] c = linha.split(",", -1);
                String nome     = c[0].trim();
                String tipo     = c[1].trim();
                String poder    = c[2].trim();
                String precisao = c[3].trim();
                String cat      = c[4].trim();

                ps.setString(1, nome);
                ps.setInt(2, tipoIds.get(tipo));
                if (poder.isEmpty())    ps.setNull(3, Types.INTEGER); else ps.setInt(3, Integer.parseInt(poder));
                if (precisao.isEmpty()) ps.setNull(4, Types.INTEGER); else ps.setInt(4, Integer.parseInt(precisao));
                ps.setString(5, cat);
                ps.executeUpdate();

                try (var keys = ps.getGeneratedKeys()) {
                    if (keys.next()) golpeIds.put(nome, keys.getInt(1));
                }
            }
        } catch (Exception e) {
            conn.rollback();
            throw new RuntimeException("Falha ao ler golpes.csv", e);
        }

        // 2) 1 golpe por Pokemon
        int total = 0;
        try (InputStream in = MoveSeeder.class.getResourceAsStream("/pokemon_golpes.csv");
             BufferedReader br = new BufferedReader(new InputStreamReader(in, StandardCharsets.UTF_8));
             PreparedStatement ps = conn.prepareStatement(
                     "INSERT OR IGNORE INTO pokemon_golpe(pokemon_id, golpe_id) VALUES (?,?)")) {

            String linha;
            boolean primeira = true;
            while ((linha = br.readLine()) != null) {
                if (primeira) { primeira = false; continue; }
                if (linha.isBlank()) continue;

                String[] c = linha.split(",", -1);
                int pokemonId   = Integer.parseInt(c[0].trim());
                String golpeNome = c[1].trim();
                Integer golpeId = golpeIds.get(golpeNome);
                if (golpeId == null) {
                    throw new IllegalStateException("Golpe sem catalogo: " + golpeNome);
                }

                ps.setInt(1, pokemonId);
                ps.setInt(2, golpeId);
                ps.executeUpdate();
                total++;
            }
        } catch (Exception e) {
            conn.rollback();
            throw new RuntimeException("Falha ao ler pokemon_golpes.csv", e);
        }

        conn.commit();
        conn.setAutoCommit(true);
        System.out.println("[OK] " + golpeIds.size() + " golpes no catalogo, " + total + " golpes atribuidos (1 por Pokemon).");
    }
}
