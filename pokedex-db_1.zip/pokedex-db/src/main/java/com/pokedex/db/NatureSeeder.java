package com.pokedex.db;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Types;

/**
 * Insere as 25 natures do jogo. Cada nature aumenta uma stat e reduz outra
 * (HP nunca e afetado). As 5 neutras tem stat_aumentada/stat_reduzida = NULL.
 * Os nomes das stats batem com as colunas de pokemon: ataque, defesa,
 * sp_atk, sp_def, velocidade.
 */
public class NatureSeeder {

    // {nome, stat_aumentada, stat_reduzida}  (null,null = neutra)
    private static final String[][] NATURES = {
            {"Hardy",   null,         null},
            {"Lonely",  "ataque",     "defesa"},
            {"Brave",   "ataque",     "velocidade"},
            {"Adamant", "ataque",     "sp_atk"},
            {"Naughty", "ataque",     "sp_def"},
            {"Bold",    "defesa",     "ataque"},
            {"Docile",  null,         null},
            {"Relaxed", "defesa",     "velocidade"},
            {"Impish",  "defesa",     "sp_atk"},
            {"Lax",     "defesa",     "sp_def"},
            {"Timid",   "velocidade", "ataque"},
            {"Hasty",   "velocidade", "defesa"},
            {"Serious", null,         null},
            {"Jolly",   "velocidade", "sp_atk"},
            {"Naive",   "velocidade", "sp_def"},
            {"Modest",  "sp_atk",     "ataque"},
            {"Mild",    "sp_atk",     "defesa"},
            {"Quiet",   "sp_atk",     "velocidade"},
            {"Bashful", null,         null},
            {"Rash",    "sp_atk",     "sp_def"},
            {"Calm",    "sp_def",     "ataque"},
            {"Gentle",  "sp_def",     "defesa"},
            {"Sassy",   "sp_def",     "velocidade"},
            {"Careful", "sp_def",     "sp_atk"},
            {"Quirky",  null,         null},
    };

    public void inserir(Connection conn) throws SQLException {
        conn.setAutoCommit(false);
        try (PreparedStatement ps = conn.prepareStatement(
                "INSERT INTO nature(nome, stat_aumentada, stat_reduzida) VALUES (?,?,?)")) {
            for (String[] n : NATURES) {
                ps.setString(1, n[0]);
                if (n[1] == null) ps.setNull(2, Types.VARCHAR); else ps.setString(2, n[1]);
                if (n[2] == null) ps.setNull(3, Types.VARCHAR); else ps.setString(3, n[2]);
                ps.addBatch();
            }
            ps.executeBatch();
        }
        conn.commit();
        conn.setAutoCommit(true);
        System.out.println("[OK] " + NATURES.length + " natures inseridas.");
    }
}
