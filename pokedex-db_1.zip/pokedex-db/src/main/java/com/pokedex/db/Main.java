package com.pokedex.db;

import java.io.File;
import java.sql.Connection;
import java.util.Map;

/**
 * Ponto de entrada. Cria o arquivo pokedex.db do zero e popula tudo:
 * tipos -> Pokemon (CSV) -> TypeChart -> natures -> golpes.
 */
public class Main {

    public static void main(String[] args) throws Exception {
        String arquivoDb = args.length > 0 ? args[0] : "pokedex.db";

        // Recria do zero para a build ser sempre limpa e repetivel.
        File f = new File(arquivoDb);
        if (f.exists() && f.delete()) {
            System.out.println("[INFO] " + arquivoDb + " antigo removido.");
        }

        Database db = new Database(arquivoDb);
        try (Connection conn = db.conectar()) {
            db.criarEsquema(conn);

            new TipoSeeder().inserir(conn);
            Map<String, Integer> tipoIds = TipoSeeder.carregarMapa(conn);

            new CsvImporter().importar(conn, tipoIds);
            new TypeChartSeeder().inserir(conn, tipoIds);
            new NatureSeeder().inserir(conn);
            new MoveSeeder().inserir(conn, tipoIds);
        }

        System.out.println("\n=== Banco '" + arquivoDb + "' criado com sucesso! ===");
    }
}
