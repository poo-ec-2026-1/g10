package com.pokedex.db;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Map;

/**
 * Le o arquivo pokemons.csv (em resources) e popula as tabelas
 * pokemon e pokemon_tipo. Aqui sao aplicadas as correcoes:
 *  - o cabecalho e ignorado (nao vira um Pokemon);
 *  - tipo_2 vazio nao gera linha em pokemon_tipo (representa NULL);
 *  - as estatisticas sao gravadas como INTEGER.
 */
public class CsvImporter {

    public void importar(Connection conn, Map<String, Integer> tipoIds) throws SQLException {
        String sqlPokemon =
                "INSERT INTO pokemon(id, nome, hp, ataque, defesa, sp_atk, sp_def, velocidade, sprite_url) " +
                "VALUES (?,?,?,?,?,?,?,?,?)";
        String sqlTipo =
                "INSERT OR IGNORE INTO pokemon_tipo(pokemon_id, tipo_id, slot) VALUES (?,?,?)";

        conn.setAutoCommit(false);
        int total = 0;

        try (InputStream in = CsvImporter.class.getResourceAsStream("/pokemons.csv");
             BufferedReader br = new BufferedReader(new InputStreamReader(in, StandardCharsets.UTF_8));
             PreparedStatement psPokemon = conn.prepareStatement(sqlPokemon);
             PreparedStatement psTipo = conn.prepareStatement(sqlTipo)) {

            String linha;
            boolean primeira = true;
            while ((linha = br.readLine()) != null) {
                if (primeira) { primeira = false; continue; }   // pula o cabecalho
                if (linha.isBlank()) continue;

                // -1 mantem campos vazios no fim (tipo_2 vazio)
                String[] c = linha.split(",", -1);
                int id           = Integer.parseInt(c[0].trim());
                String nome      = c[1].trim();
                String tipo1     = c[2].trim();
                String tipo2     = c[3].trim();
                int hp           = Integer.parseInt(c[4].trim());
                int ataque       = Integer.parseInt(c[5].trim());
                int defesa       = Integer.parseInt(c[6].trim());
                int spAtk        = Integer.parseInt(c[7].trim());
                int spDef        = Integer.parseInt(c[8].trim());
                int velocidade   = Integer.parseInt(c[9].trim());
                String spriteUrl = c[10].trim();

                psPokemon.setInt(1, id);
                psPokemon.setString(2, nome);
                psPokemon.setInt(3, hp);
                psPokemon.setInt(4, ataque);
                psPokemon.setInt(5, defesa);
                psPokemon.setInt(6, spAtk);
                psPokemon.setInt(7, spDef);
                psPokemon.setInt(8, velocidade);
                psPokemon.setString(9, spriteUrl);
                psPokemon.executeUpdate();

                // tipo primario (slot 1)
                psTipo.setInt(1, id);
                psTipo.setInt(2, tipoIds.get(tipo1));
                psTipo.setInt(3, 1);
                psTipo.executeUpdate();

                // tipo secundario (slot 2) - so se existir
                if (!tipo2.isEmpty()) {
                    psTipo.setInt(1, id);
                    psTipo.setInt(2, tipoIds.get(tipo2));
                    psTipo.setInt(3, 2);
                    psTipo.executeUpdate();
                }
                total++;
            }
        } catch (Exception e) {
            conn.rollback();
            throw new RuntimeException("Falha ao importar o CSV", e);
        }

        conn.commit();
        conn.setAutoCommit(true);
        System.out.println("[OK] " + total + " Pokemon importados do CSV.");
    }
}
