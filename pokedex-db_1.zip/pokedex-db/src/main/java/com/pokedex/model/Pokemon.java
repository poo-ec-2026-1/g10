package com.pokedex.model;

import java.util.ArrayList;
import java.util.List;

/**
 * Representa uma linha da tabela pokemon (mais os tipos e o golpe).
 * E um objeto Java puro (POJO): a interface trabalha com ele, nunca com SQL.
 * Corresponde a classe Pokemon da UML do Gabriel.
 */
public class Pokemon {

    private int id;
    private String nome;
    private int hp;
    private int ataque;
    private int defesa;
    private int spAtk;
    private int spDef;
    private int velocidade;
    private String spriteUrl;

    private final List<String> tipos = new ArrayList<>(); // 1 ou 2 tipos
    private String golpe;                                 // golpe caracteristico

    public int getId() { return id; }
    public void setId(int id) { this.id = id; }

    public String getNome() { return nome; }
    public void setNome(String nome) { this.nome = nome; }

    public int getHp() { return hp; }
    public void setHp(int hp) { this.hp = hp; }

    public int getAtaque() { return ataque; }
    public void setAtaque(int ataque) { this.ataque = ataque; }

    public int getDefesa() { return defesa; }
    public void setDefesa(int defesa) { this.defesa = defesa; }

    public int getSpAtk() { return spAtk; }
    public void setSpAtk(int spAtk) { this.spAtk = spAtk; }

    public int getSpDef() { return spDef; }
    public void setSpDef(int spDef) { this.spDef = spDef; }

    public int getVelocidade() { return velocidade; }
    public void setVelocidade(int velocidade) { this.velocidade = velocidade; }

    public String getSpriteUrl() { return spriteUrl; }
    public void setSpriteUrl(String spriteUrl) { this.spriteUrl = spriteUrl; }

    public List<String> getTipos() { return tipos; }

    public String getGolpe() { return golpe; }
    public void setGolpe(String golpe) { this.golpe = golpe; }

    /** Atalho util pra UI: "Fire" ou "Fire / Flying". */
    public String getTiposFormatados() {
        return String.join(" / ", tipos);
    }

    @Override
    public String toString() {
        return "#" + id + " " + nome + " (" + getTiposFormatados() + ") - " + golpe;
    }
}
